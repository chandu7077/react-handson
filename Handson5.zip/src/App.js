
import "bootstrap/dist/css/bootstrap.css";
import CountPeople from "../src/Components/CountPeople";
function App() {
  return (
    <div className="container">
      <CountPeople/>
    </div>
  );
}

export default App;
