import OnlineShooping from "../src/Components/OnlineShopping";
import "bootstrap/dist/css/bootstrap.css";
function App() {
  return (
    <div className="container">
      <OnlineShooping />
    </div>
  );
}

export default App;
